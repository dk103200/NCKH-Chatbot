from typing import Any, Text, Dict, List
from rasa_sdk.events import FollowupAction
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
import random
# from utility import *
import os
import dateparser
from pyvi import ViTokenizer
import re
import pandas as pd
from get_tkb import svtkb
regrex = r'([0-9]{13})'
tkb_filename = 'tkb.json'
class ActionShowSchedule(Action):

    def name(self) -> Text:
        return "action_show_schedule"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        message = tracker.latest_message.get('text')

        if os.path.isfile(tkb_filename):
            tkb = pd.read_json(tkb_filename)
            tokens = ViTokenizer.tokenize(message)
            print('tokens', tokens)
            for token in tokens.split(' '):
                if token.find('_')>0 and dateparser.parse(token.replace('_',' '), languages=['vi']):
                    dates = dateparser.parse(token.replace('_',' '), languages=['vi']).weekday()
                    print('date', dates)
                    list_course = tkb[tkb['day'] == dates+2]
                    response = ''
                    if len(list_course):
                        for _, row in list_course.iterrows():
                            response += "Bạn có môn học {} từ tiết {} đến tiết {} ở phòng {} \n".format(row['name'], row['from'], row['to'], row['room'])
                    else:
                        response = 'Hôm nay bạn không có lịch học'
                else:
                    response = 'Không xác định ngày'
            dispatcher.utter_message(text=response)
        else:
            mssv = re.search(regrex, message)
            print('mssv : ', mssv)
            try:
                _ = svtkb(mssv[0])
                dispatcher.utter_message(text='Đã tải thời khoá biểu')
            except :
                dispatcher.utter_message(text='Vui lòng nhập MSSV')
        return []