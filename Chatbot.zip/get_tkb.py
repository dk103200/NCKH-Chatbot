import requests
from bs4 import BeautifulSoup
import pandas as pd

def svtkb(masv):
    tkb_data = {
        'maSV': masv    
    }
    
    r = requests.get('http://daotao.ute.udn.vn/timetable.asp')
    soup = BeautifulSoup(r.content, 'lxml')

    tkb_data['form_id'] = soup.find('input', attrs = {'name': 'maSV'})

    url = "http://daotao.ute.udn.vn/svtkb.asp"

    r = requests.post(url, data=tkb_data)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.content, 'lxml')

    table = pd.read_html(soup.prettify())[0]
    table = table.rename(columns = {0 :'course', 1 : 'name', 2 : 'day', 3 : 'from', 4 : 'to', 5 : 'teacher', 6 : 'room'})
    table.to_json('tkb.json')
    return table
